<?php
/**
 * User: Wisp X
 * Date: 2018-12-27
 * Time: 11:08
 * Link: https://github.com/wisp-x
 */

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;

class Folders extends Model
{
    use SoftDelete;
}
